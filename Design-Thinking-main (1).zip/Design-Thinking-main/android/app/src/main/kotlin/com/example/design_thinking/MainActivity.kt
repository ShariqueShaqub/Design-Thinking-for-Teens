package com.example.design_thinking

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
